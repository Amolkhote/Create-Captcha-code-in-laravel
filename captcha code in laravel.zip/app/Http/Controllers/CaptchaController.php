<?php
namespace App\Http\Controllers;

use Dotenv\Validator;
use Illuminate\Http\Request;
use Mews\Captcha;
class CaptchaController extends Controller
{
    public function create()
    {
        return view('amol12');
    }
    public function captchaValidate(Request $request)
    {

        $this->validate($request, [
            'name' => 'required',
            'email' => 'required|email',
            'password' => 'required|min:6',
            'captcha' => 'required|captcha'
        ], ['captcha.captcha'=>'Invalid captcha Code']);


            dd($request->all());
            echo"All Done";

    }
    public function refreshCaptcha()
    {
         return captcha_img('flat');
        // return response()->json(['captcha_img'=> captcha_img('flat')]);

    }

}
